# Verification notes

## Checks completed in the available environment

- All 11 XML resource / manifest files parsed successfully as XML.
- Project-local resource references were checked; no missing referenced drawable, color, string or layout was found.
- The SQLite schema and equivalent SQL operations were exercised with SQLite: unique roll numbers, unique student-subject-date attendance keys, attendance upsert/edit behavior, foreign-key cascade on student deletion, and subject class-count aggregation all passed.
- The Gradle bootstrap launcher itself compiled with Java 8 bytecode compatibility.
- A Gradle `assembleDebug` attempt was made. The launcher tried to fetch Gradle 8.7 from `services.gradle.org`, but the environment could not resolve the host (`UnknownHostException`). The build did not reach Android Gradle Plugin configuration or Java/Android compilation.

## Checks not performed

- Full Android Java compilation (no Android SDK / `android.jar` was available).
- APK generation, installation, launch, emulator testing, rotation testing or on-device persistence testing.
- End-to-end UI testing of student CRUD, attendance editing, reports and CSV sharing.

The app source implements these workflows, but they must be built and exercised in Android Studio on a machine with the Android SDK and network access before submission as a tested binary.
