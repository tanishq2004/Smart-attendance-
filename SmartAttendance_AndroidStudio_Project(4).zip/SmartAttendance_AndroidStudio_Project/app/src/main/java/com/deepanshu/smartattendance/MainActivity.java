package com.deepanshu.smartattendance;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.OpenableColumns;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Main screen controller for the offline Smart Attendance app. */
public class MainActivity extends Activity {
    private static final int REQUEST_CREATE_CSV = 4102;
    private DatabaseHelper database;
    private FrameLayout root;
    private LinearLayout pageContent;
    private LinearLayout page;
    private String currentScreen = "dashboard";
    private String selectedDate;
    private long selectedSubjectId = -1;
    private List<DatabaseHelper.Subject> attendanceSubjects = new ArrayList<>();
    private Map<Long, Boolean> attendanceStates = new LinkedHashMap<>();
    private LinearLayout attendanceRows;
    private String pendingCsv = "";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        root = findViewById(R.id.app_root);
        database = new DatabaseHelper(this);
        selectedDate = todayIso();
        getWindow().setStatusBarColor(getColorCompat(R.color.navy));
        getWindow().setNavigationBarColor(getColorCompat(R.color.surface));
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        showSplash();
    }

    private void showSplash() {
        root.removeAllViews();
        LinearLayout splash = new LinearLayout(this);
        splash.setOrientation(LinearLayout.VERTICAL);
        splash.setGravity(Gravity.CENTER);
        splash.setBackgroundColor(getColorCompat(R.color.navy));
        TextView mark = new TextView(this); mark.setText("✓"); mark.setTextSize(38); mark.setTextColor(getColorCompat(R.color.royal_blue)); mark.setGravity(Gravity.CENTER);
        GradientDrawable logoBg = new GradientDrawable(); logoBg.setColor(0xFFFFFFFF); logoBg.setCornerRadius(dp(25)); mark.setBackground(logoBg);
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(dp(82),dp(82)); mp.bottomMargin=dp(22); splash.addView(mark,mp);
        TextView title = new TextView(this); title.setText("SMART ATTENDANCE"); title.setTextColor(0xFFFFFFFF); title.setTextSize(21); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); title.setLetterSpacing(.08f); splash.addView(title);
        TextView subtitle = new TextView(this); subtitle.setText("Simple • Smart • Offline"); subtitle.setTextColor(0xFFB9C8E4); subtitle.setTextSize(13); subtitle.setPadding(0,dp(9),0,0); splash.addView(subtitle);
        root.addView(splash,new FrameLayout.LayoutParams(-1,-1));
        new Handler().postDelayed(this::showDashboard,650);
    }

    private int getColorCompat(int id) { return getResources().getColor(id); }
    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + .5f); }
    private String todayIso() { return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date()); }
    private String prettyDate(String iso) {
        try { return new SimpleDateFormat("dd MMM yyyy",Locale.getDefault()).format(new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(iso)); }
        catch(Exception e) { return iso; }
    }

    private void beginScreen(String title, boolean back) {
        root.removeAllViews();
        page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setBackgroundColor(getColorCompat(R.color.screen_background));
        LinearLayout toolbar = new LinearLayout(this); toolbar.setOrientation(LinearLayout.HORIZONTAL); toolbar.setGravity(Gravity.CENTER_VERTICAL); toolbar.setPadding(dp(18),dp(13),dp(18),dp(13)); toolbar.setBackgroundColor(getColorCompat(R.color.navy));
        if (back) {
            TextView backView = new TextView(this); backView.setText("‹"); backView.setTextSize(34); backView.setTextColor(0xFFFFFFFF); backView.setGravity(Gravity.CENTER); toolbar.addView(backView,new LinearLayout.LayoutParams(dp(34),dp(42)));
            backView.setOnClickListener(v -> showDashboard());
        }
        TextView heading = new TextView(this); heading.setText(title); heading.setTextSize(19); heading.setTypeface(Typeface.DEFAULT,Typeface.BOLD); heading.setTextColor(0xFFFFFFFF);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(0,-2,1); if (!back) hp.leftMargin=dp(2); toolbar.addView(heading,hp);
        TextView mini = new TextView(this); mini.setText("SA"); mini.setTextSize(12); mini.setTypeface(Typeface.DEFAULT,Typeface.BOLD); mini.setTextColor(0xFFFFFFFF); mini.setGravity(Gravity.CENTER);
        GradientDrawable circle = new GradientDrawable(); circle.setColor(0x33FFFFFF); circle.setCornerRadius(dp(18)); mini.setBackground(circle); toolbar.addView(mini,new LinearLayout.LayoutParams(dp(36),dp(36)));
        page.addView(toolbar,new LinearLayout.LayoutParams(-1,dp(62)));
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setClipToPadding(false); scroll.setPadding(0,0,0,dp(14));
        pageContent = new LinearLayout(this); pageContent.setOrientation(LinearLayout.VERTICAL); pageContent.setPadding(dp(18),dp(18),dp(18),dp(18)); scroll.addView(pageContent,new ScrollView.LayoutParams(-1,-2));
        page.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        root.addView(page,new FrameLayout.LayoutParams(-1,-1));
    }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); t.setIncludeFontPadding(true); return t;
    }
    private LinearLayout vertical() { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout horizontal() { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private LinearLayout card() { LinearLayout l=vertical(); l.setBackgroundResource(R.drawable.bg_card); l.setPadding(dp(16),dp(15),dp(16),dp(15)); return l; }
    private void gap(LinearLayout parent,int height) { View v=new View(this); parent.addView(v,new LinearLayout.LayoutParams(1,dp(height))); }
    private void section(LinearLayout parent,String title,String subtitle) {
        TextView h=text(title,16,getColorCompat(R.color.text_primary),true); parent.addView(h);
        if(subtitle!=null&&!subtitle.isEmpty()){ TextView s=text(subtitle,12,getColorCompat(R.color.text_secondary),false); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(4);parent.addView(s,p); }
        gap(parent,12);
    }
    private Button actionButton(String label, boolean primary, Runnable action) {
        Button b=new Button(this); b.setText(label); b.setAllCaps(false); b.setTextSize(13); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setMinHeight(dp(44)); b.setPadding(dp(14),dp(4),dp(14),dp(4));
        b.setTextColor(primary?0xFFFFFFFF:getColorCompat(R.color.royal_blue)); b.setBackgroundResource(primary?R.drawable.bg_primary_button:R.drawable.bg_secondary_button); b.setElevation(dp(1));
        b.setOnClickListener(v -> action.run()); return b;
    }
    private void addButton(LinearLayout parent,String label,boolean primary,Runnable action) {
        Button b=actionButton(label,primary,action); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(9);parent.addView(b,p);
    }
    private void addPillRow(LinearLayout parent, Button a, Button b) {
        LinearLayout row=horizontal(); row.setGravity(Gravity.CENTER); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(8);parent.addView(row,p);
        LinearLayout.LayoutParams w=new LinearLayout.LayoutParams(0,-2,1); w.rightMargin=dp(6); row.addView(a,w); LinearLayout.LayoutParams w2=new LinearLayout.LayoutParams(0,-2,1);w2.leftMargin=dp(6);row.addView(b,w2);
    }
    private void showEmpty(LinearLayout parent,String title,String subtitle) {
        LinearLayout box=card(); box.setGravity(Gravity.CENTER); TextView icon=text("○",28,getColorCompat(R.color.royal_blue),true); box.addView(icon);
        TextView h=text(title,15,getColorCompat(R.color.text_primary),true); LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-2,-2);hp.topMargin=dp(8);box.addView(h,hp);
        TextView s=text(subtitle,12,getColorCompat(R.color.text_secondary),false);s.setGravity(Gravity.CENTER);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=dp(5);box.addView(s,sp);
        parent.addView(box,new LinearLayout.LayoutParams(-1,-2));
    }

    private void showDashboard() {
        currentScreen="dashboard"; beginScreen("Dashboard",false);
        int[] stats=database.getDashboardStats(todayIso());
        TextView welcome=text("Good day, Deepanshu 👋",20,getColorCompat(R.color.text_primary),true); pageContent.addView(welcome);
        TextView date=text(new SimpleDateFormat("EEEE, dd MMMM yyyy",Locale.getDefault()).format(new Date()),13,getColorCompat(R.color.text_secondary),false); LinearLayout.LayoutParams dp1=new LinearLayout.LayoutParams(-1,-2);dp1.topMargin=dp(5);pageContent.addView(date,dp1);
        gap(pageContent,18);
        LinearLayout hero=vertical(); hero.setPadding(dp(18),dp(18),dp(18),dp(18)); hero.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{getColorCompat(R.color.navy),getColorCompat(R.color.royal_blue)})); ((GradientDrawable)hero.getBackground()).setCornerRadius(dp(20));
        hero.addView(text("OVERALL ATTENDANCE",11,0xFFD8E4FF,true));
        LinearLayout hr=horizontal(); TextView percent=text(stats[4]+"%",34,0xFFFFFFFF,true); hr.addView(percent); TextView label=text("  all recorded classes",12,0xFFD8E4FF,false);hr.addView(label); LinearLayout.LayoutParams hrlp=new LinearLayout.LayoutParams(-1,-2);hrlp.topMargin=dp(6);hero.addView(hr,hrlp);
        pageContent.addView(hero,new LinearLayout.LayoutParams(-1,-2)); gap(pageContent,18);
        section(pageContent,"Attendance overview","Live totals from your local database");
        LinearLayout grid1=horizontal(); grid1.addView(metricCard("Students",String.valueOf(stats[0]),"♙",getColorCompat(R.color.royal_blue)),new LinearLayout.LayoutParams(0,-2,1));
        View spacer=new View(this);grid1.addView(spacer,new LinearLayout.LayoutParams(dp(10),1));grid1.addView(metricCard("Today's records",String.valueOf(stats[1]),"▣",getColorCompat(R.color.navy)),new LinearLayout.LayoutParams(0,-2,1));pageContent.addView(grid1);
        gap(pageContent,10); LinearLayout grid2=horizontal(); grid2.addView(metricCard("Present today",String.valueOf(stats[2]),"✓",getColorCompat(R.color.green)),new LinearLayout.LayoutParams(0,-2,1));
        View spacer2=new View(this);grid2.addView(spacer2,new LinearLayout.LayoutParams(dp(10),1));grid2.addView(metricCard("Absent today",String.valueOf(stats[3]),"!",getColorCompat(R.color.red)),new LinearLayout.LayoutParams(0,-2,1));pageContent.addView(grid2);
        gap(pageContent,20); section(pageContent,"Quick actions","Everything you need, one tap away");
        addButton(pageContent,"＋  Add a student",true,this::showStudentManagement);
        addButton(pageContent,"✓  Mark attendance",false,this::showAttendance);
        addButton(pageContent,"▤  View attendance reports",false,this::showReports);
        addButton(pageContent,"⚙  Settings & export",false,this::showSettings);
        gap(pageContent,15); TextView footer=text("SMART ATTENDANCE  •  COLLEGE PROJECT",10,getColorCompat(R.color.text_secondary),true);footer.setGravity(Gravity.CENTER);pageContent.addView(footer);
    }

    private LinearLayout metricCard(String label,String value,String symbol,int accent) {
        LinearLayout c=card(); c.setMinimumHeight(dp(104)); LinearLayout top=horizontal(); TextView i=text(symbol,19,accent,true); top.addView(i); c.addView(top);
        TextView v=text(value,25,getColorCompat(R.color.text_primary),true);LinearLayout.LayoutParams vp=new LinearLayout.LayoutParams(-1,-2);vp.topMargin=dp(5);c.addView(v,vp);
        TextView l=text(label,11,getColorCompat(R.color.text_secondary),false);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(2);c.addView(l,lp);return c;
    }

    private void showStudentManagement() {
        currentScreen="students"; beginScreen("Student management",true);
        LinearLayout intro=horizontal(); intro.addView(text("Your student directory",17,getColorCompat(R.color.text_primary),true),new LinearLayout.LayoutParams(0,-2,1));intro.addView(actionButton("＋ Add",true,()->showStudentDialog(null)));
        pageContent.addView(intro); gap(pageContent,12);
        EditText search=new EditText(this); search.setSingleLine(true); search.setHint("Search name or roll number"); search.setTextSize(14); search.setPadding(dp(14),0,dp(14),0); search.setBackground(cardBackground()); pageContent.addView(search,new LinearLayout.LayoutParams(-1,dp(50))); gap(pageContent,12);
        LinearLayout list=vertical(); pageContent.addView(list);
        Runnable refresh=()->renderStudentList(list,search.getText().toString()); refresh.run();
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int before,int count){refresh.run();} public void afterTextChanged(Editable e){}});
    }

    private android.graphics.drawable.Drawable cardBackground() {
        GradientDrawable d=new GradientDrawable();d.setColor(0xFFFFFFFF);d.setCornerRadius(dp(14));d.setStroke(dp(1),0xFFE7ECF4);return d;
    }

    private void renderStudentList(LinearLayout list,String filter) {
        list.removeAllViews(); List<DatabaseHelper.Student> students=database.getStudents(filter);
        if(students.isEmpty()){showEmpty(list,filter.isEmpty()?"No students added yet":"No matching students","Add a student to start recording attendance.");return;}
        TextView count=text(students.size()+" student"+(students.size()==1?"":"s"),12,getColorCompat(R.color.text_secondary),true);list.addView(count);gap(list,8);
        for(DatabaseHelper.Student s:students){
            LinearLayout c=card(); LinearLayout top=horizontal();
            TextView avatar=text(initials(s.name),13,0xFFFFFFFF,true);avatar.setGravity(Gravity.CENTER);GradientDrawable circle=new GradientDrawable();circle.setColor(getColorCompat(R.color.royal_blue));circle.setShape(GradientDrawable.OVAL);avatar.setBackground(circle);top.addView(avatar,new LinearLayout.LayoutParams(dp(42),dp(42)));
            LinearLayout info=vertical();LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(0,-2,1);ip.leftMargin=dp(11);top.addView(info,ip);
            info.addView(text(s.name,15,getColorCompat(R.color.text_primary),true));info.addView(text("Roll no. "+s.roll,12,getColorCompat(R.color.text_secondary),false));c.addView(top);
            TextView meta=text(s.course+"  •  Semester "+s.semester,12,getColorCompat(R.color.text_secondary),false);LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,-2);mp.topMargin=dp(10);c.addView(meta,mp);
            Button edit=actionButton("Edit",false,()->showStudentDialog(s));Button del=actionButton("Delete",false,()->confirmDeleteStudent(s));addPillRow(c,edit,del);
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.bottomMargin=dp(10);list.addView(c,cp);
        }
    }
    private String initials(String name) { String[] p=name.trim().split("\\s+"); return p.length>1?(p[0].substring(0,1)+p[p.length-1].substring(0,1)).toUpperCase(Locale.getDefault()):name.substring(0,1).toUpperCase(Locale.getDefault()); }

    private void showStudentDialog(DatabaseHelper.Student student) {
        View form=getLayoutInflater().inflate(R.layout.dialog_student,null);
        EditText name=form.findViewById(R.id.input_student_name),roll=form.findViewById(R.id.input_roll_number),course=form.findViewById(R.id.input_course),semester=form.findViewById(R.id.input_semester);
        if(student!=null){name.setText(student.name);roll.setText(student.roll);course.setText(student.course);semester.setText(student.semester);}
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(student==null?"Add student":"Edit student").setView(form).setNegativeButton("Cancel",null).setPositiveButton(student==null?"Add student":"Save changes",null).create();
        dialog.setOnShowListener(d->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            String n=name.getText().toString().trim(),r=roll.getText().toString().trim(),co=course.getText().toString().trim(),sem=semester.getText().toString().trim();
            if(n.isEmpty()||r.isEmpty()||co.isEmpty()||sem.isEmpty()){toast("Please complete all student fields.");return;}
            if(!sem.matches("\\d{1,2}") || Integer.parseInt(sem)<1 || Integer.parseInt(sem)>12){toast("Enter a valid semester number (1–12).");return;}
            if(!database.saveStudent(student==null?0:student.id,n,r,co,sem)){toast("That roll number is already registered.");return;}
            dialog.dismiss();toast(student==null?"Student added":"Student updated");if("students".equals(currentScreen))showStudentManagement();else showStudentDetails(student==null?findStudentIdByRoll(r):student.id);
        }));dialog.show();
    }
    private long findStudentIdByRoll(String roll) { for(DatabaseHelper.Student s:database.getStudents(roll))if(s.roll.equalsIgnoreCase(roll))return s.id;return -1; }
    private void confirmDeleteStudent(DatabaseHelper.Student s) {
        new AlertDialog.Builder(this).setTitle("Delete student?").setMessage("Delete "+s.name+" and all of their attendance records? This cannot be undone.").setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->{database.deleteStudent(s.id);toast("Student deleted");showStudentManagement();}).show();
    }

    private void showAttendance() {
        currentScreen="attendance"; beginScreen("Mark attendance",true);
        section(pageContent,"Take attendance","Choose a date and subject, then mark each student.");
        LinearLayout dateCard=card(); dateCard.addView(text("ATTENDANCE DATE",10,getColorCompat(R.color.text_secondary),true));
        Button dateButton=actionButton("▦  "+prettyDate(selectedDate),false,()->openDatePicker(dateButtonRef[0]));
        dateButtonRef[0]=dateButton;LinearLayout.LayoutParams dbp=new LinearLayout.LayoutParams(-1,-2);dbp.topMargin=dp(7);dateCard.addView(dateButton,dbp);pageContent.addView(dateCard);gap(pageContent,10);
        LinearLayout subjectCard=card();subjectCard.addView(text("SUBJECT",10,getColorCompat(R.color.text_secondary),true));
        LinearLayout subjectRow=horizontal();Spinner spinner=new Spinner(this);attendanceSubjects=database.getSubjects();List<String> labels=new ArrayList<>();for(DatabaseHelper.Subject s:attendanceSubjects)labels.add(s.name);
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,labels);adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);spinner.setAdapter(adapter);
        if(!attendanceSubjects.isEmpty()){int index=0;for(int i=0;i<attendanceSubjects.size();i++)if(attendanceSubjects.get(i).id==selectedSubjectId)index=i;if(index<0)index=0;spinner.setSelection(index);selectedSubjectId=attendanceSubjects.get(index).id;}
        subjectRow.addView(spinner,new LinearLayout.LayoutParams(0,dp(48),1));Button add=actionButton("＋ Subject",false,this::showAddSubjectDialog);LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-2,-2);ap.leftMargin=dp(8);subjectRow.addView(add,ap);subjectCard.addView(subjectRow);pageContent.addView(subjectCard);gap(pageContent,15);
        LinearLayout controls=horizontal();controls.addView(text("Registered students",16,getColorCompat(R.color.text_primary),true),new LinearLayout.LayoutParams(0,-2,1));controls.addView(actionButton("✓ All present",false,()->{for(DatabaseHelper.Student s:database.getStudents(""))attendanceStates.put(s.id,true);renderAttendanceRows();}));pageContent.addView(controls);gap(pageContent,9);
        attendanceRows=vertical();pageContent.addView(attendanceRows);
        spinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){if(pos>=0&&pos<attendanceSubjects.size()){selectedSubjectId=attendanceSubjects.get(pos).id;loadAttendanceStates();renderAttendanceRows();}}public void onNothingSelected(android.widget.AdapterView<?> p){selectedSubjectId=-1;}});
        loadAttendanceStates();renderAttendanceRows();
        gap(pageContent,10);addButton(pageContent,"Save attendance",true,()->saveAttendanceNow());
        TextView note=text("You can reopen the same date and subject later to edit saved attendance.",11,getColorCompat(R.color.text_secondary),false);note.setGravity(Gravity.CENTER);LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2);np.topMargin=dp(8);pageContent.addView(note,np);
    }
    private final Button[] dateButtonRef=new Button[1];
    private void openDatePicker(Button button) {
        Calendar cal=Calendar.getInstance();try{cal.setTime(new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(selectedDate));}catch(Exception ignored){}
        new DatePickerDialog(this,(view,y,m,d)->{Calendar c=Calendar.getInstance();c.set(y,m,d);selectedDate=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());if(button!=null)button.setText("▦  "+prettyDate(selectedDate));loadAttendanceStates();renderAttendanceRows();},cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH)).show();
    }
    private void loadAttendanceStates() {
        attendanceStates.clear();if(selectedSubjectId>0)attendanceStates.putAll(database.getAttendanceForDate(selectedSubjectId,selectedDate));
        for(DatabaseHelper.Student s:database.getStudents(""))if(!attendanceStates.containsKey(s.id))attendanceStates.put(s.id,false);
    }
    private void renderAttendanceRows() {
        if(attendanceRows==null)return;attendanceRows.removeAllViews();List<DatabaseHelper.Student> students=database.getStudents("");
        if(students.isEmpty()){showEmpty(attendanceRows,"No students to mark","Add students from Student management first.");return;}
        if(attendanceSubjects.isEmpty()){showEmpty(attendanceRows,"Create a subject first","Use the + Subject button above, then mark attendance.");return;}
        for(DatabaseHelper.Student s:students){
            LinearLayout c=card();LinearLayout line=horizontal();LinearLayout info=vertical();info.addView(text(s.name,14,getColorCompat(R.color.text_primary),true));info.addView(text(s.roll+"  •  "+s.course,11,getColorCompat(R.color.text_secondary),false));line.addView(info,new LinearLayout.LayoutParams(0,-2,1));
            RadioGroup group=new RadioGroup(this);group.setOrientation(RadioGroup.HORIZONTAL);RadioButton present=new RadioButton(this);present.setText("P");present.setTextSize(12);present.setButtonTintList(android.content.res.ColorStateList.valueOf(getColorCompat(R.color.green)));present.setId(View.generateViewId());RadioButton absent=new RadioButton(this);absent.setText("A");absent.setTextSize(12);absent.setButtonTintList(android.content.res.ColorStateList.valueOf(getColorCompat(R.color.red)));absent.setId(View.generateViewId());group.addView(present);group.addView(absent);line.addView(group);
            boolean isPresent=Boolean.TRUE.equals(attendanceStates.get(s.id));group.check(isPresent?present.getId():absent.getId());group.setOnCheckedChangeListener((g,checked)->attendanceStates.put(s.id,checked==present.getId()));c.addView(line);
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.bottomMargin=dp(8);attendanceRows.addView(c,cp);
        }
    }
    private void showAddSubjectDialog() {
        EditText input=new EditText(this);input.setSingleLine(true);input.setHint("Subject name");input.setPadding(dp(12),dp(8),dp(12),dp(8));
        new AlertDialog.Builder(this).setTitle("Add subject").setView(input).setNegativeButton("Cancel",null).setPositiveButton("Add",(d,w)->{String name=input.getText().toString().trim();if(name.isEmpty()){toast("Enter a subject name.");return;}long id=database.addSubject(name);if(id<0){toast("This subject already exists.");return;}selectedSubjectId=id;toast("Subject added");showAttendance();}).show();
    }
    private void saveAttendanceNow() {
        if(database.getStudents("").isEmpty()){toast("Add students before saving attendance.");return;}if(selectedSubjectId<=0){toast("Please add or select a subject.");return;}
        try{int saved=database.saveAttendance(selectedSubjectId,selectedDate,attendanceStates);toast(saved+" attendance records saved");showDashboard();}catch(Exception e){toast("Could not save attendance. Please try again.");}
    }

    private void showReports() {
        currentScreen="reports";beginScreen("Attendance reports",true);
        int[] stats=database.getDashboardStats(todayIso());
        section(pageContent,"Overall performance","Calculated from every saved attendance record");
        LinearLayout overall=card();overall.addView(text("OVERALL ATTENDANCE",10,getColorCompat(R.color.text_secondary),true));overall.addView(text(stats[4]+"%",32,getColorCompat(R.color.navy),true));overall.addView(text("Present records "+countAllPresent()+"  •  Total attendance records "+countAllRecords(),12,getColorCompat(R.color.text_secondary),false));pageContent.addView(overall);gap(pageContent,18);
        section(pageContent,"Subject-wise attendance","Attendance rate for each subject");List<DatabaseHelper.SubjectSummary> subjects=database.getSubjectSummaries();
        if(subjects.isEmpty())showEmpty(pageContent,"No subjects yet","Add a subject when you start marking attendance.");
        for(DatabaseHelper.SubjectSummary s:subjects){LinearLayout c=card();c.addView(text(s.subjectName,15,getColorCompat(R.color.text_primary),true));LinearLayout r=horizontal();TextView pct=text(String.format(Locale.getDefault(),"%.1f%%",s.percentage()),20,getColorCompat(R.color.royal_blue),true);r.addView(pct,new LinearLayout.LayoutParams(0,-2,1));r.addView(text(s.present+" present / "+s.absent+" absent",11,getColorCompat(R.color.text_secondary),false));c.addView(r);c.addView(text(s.conductedClasses+" classes conducted  •  "+s.classes+" student records",11,getColorCompat(R.color.text_secondary),false));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(9);pageContent.addView(c,p);}
        gap(pageContent,8);section(pageContent,"Student performance","Tap a student to see individual history");List<DatabaseHelper.Student> students=database.getStudents("");
        if(students.isEmpty())showEmpty(pageContent,"No students yet","Add students to generate individual reports.");
        for(DatabaseHelper.Student s:students){DatabaseHelper.Summary sum=database.getStudentSummary(s.id);LinearLayout c=card();LinearLayout r=horizontal();r.addView(text(s.name+"  ·  "+s.roll,14,getColorCompat(R.color.text_primary),true),new LinearLayout.LayoutParams(0,-2,1));int color=sum.percentage()<75?getColorCompat(R.color.red):getColorCompat(R.color.green);r.addView(text(String.format(Locale.getDefault(),"%.1f%%",sum.percentage()),15,color,true));c.addView(r);c.addView(text(sum.present+" present  •  "+sum.absent+" absent  •  "+sum.classes+" classes",11,getColorCompat(R.color.text_secondary),false));if(sum.classes>0&&sum.percentage()<75){TextView warning=text("Below 75% attendance",10,getColorCompat(R.color.red),true);warning.setPadding(0,dp(6),0,0);c.addView(warning);}c.setOnClickListener(v->showStudentDetails(s.id));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(8);pageContent.addView(c,p);}
        gap(pageContent,10);addButton(pageContent,"View date-wise attendance history",false,()->showHistory(0));addButton(pageContent,"Export attendance CSV",true,()->exportCsvWithPicker());
    }
    private int countAllPresent(){int n=0;Cursor c=database.getReadableDatabase().rawQuery("SELECT COUNT(*) FROM attendance WHERE status='PRESENT'",null);try{if(c.moveToFirst())n=c.getInt(0);}finally{c.close();}return n;}
    private int countAllRecords(){int n=0;Cursor c=database.getReadableDatabase().rawQuery("SELECT COUNT(*) FROM attendance",null);try{if(c.moveToFirst())n=c.getInt(0);}finally{c.close();}return n;}

    private void showStudentDetails(long studentId) {
        DatabaseHelper.Student s=database.getStudent(studentId);if(s==null){showStudentManagement();return;}
        currentScreen="student_details";beginScreen("Student report",true);DatabaseHelper.Summary sum=database.getStudentSummary(studentId);
        LinearLayout hero=card();hero.addView(text(s.name,20,getColorCompat(R.color.text_primary),true));hero.addView(text("Roll no. "+s.roll+"  •  "+s.course+"  •  Semester "+s.semester,12,getColorCompat(R.color.text_secondary),false));gap(hero,12);
        LinearLayout row=horizontal();row.addView(metricCard("Attendance",String.format(Locale.getDefault(),"%.1f%%",sum.percentage()),"%",getColorCompat(R.color.royal_blue)),new LinearLayout.LayoutParams(0,-2,1));View sp=new View(this);row.addView(sp,new LinearLayout.LayoutParams(dp(8),1));row.addView(metricCard("Present",String.valueOf(sum.present),"✓",getColorCompat(R.color.green)),new LinearLayout.LayoutParams(0,-2,1));View sp2=new View(this);row.addView(sp2,new LinearLayout.LayoutParams(dp(8),1));row.addView(metricCard("Absent",String.valueOf(sum.absent),"!",getColorCompat(R.color.red)),new LinearLayout.LayoutParams(0,-2,1));hero.addView(row);pageContent.addView(hero);gap(pageContent,18);
        section(pageContent,"Attendance history","Every saved date and subject for this student");Cursor c=database.getHistory(studentId);int n=0;
        try{while(c.moveToNext()){n++;LinearLayout item=card();LinearLayout r=horizontal();r.addView(text(prettyDate(c.getString(0)),14,getColorCompat(R.color.text_primary),true),new LinearLayout.LayoutParams(0,-2,1));boolean p="PRESENT".equals(c.getString(2));r.addView(text(p?"PRESENT":"ABSENT",11,getColorCompat(p?R.color.green:R.color.red),true));item.addView(r);item.addView(text(c.getString(1),12,getColorCompat(R.color.text_secondary),false));LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,-2);ip.bottomMargin=dp(8);pageContent.addView(item,ip);}}finally{c.close();}
        if(n==0)showEmpty(pageContent,"No attendance recorded","This student's attendance will appear here after the first class.");
        addButton(pageContent,"Edit student details",false,()->showStudentDialog(s));
    }

    private void showHistory(long studentId) {
        currentScreen="history";beginScreen("Attendance history",true);section(pageContent,studentId>0?"Student history":"All attendance records","Sorted by most recent date first");Cursor c=database.getHistory(studentId);int n=0;String lastDate="";
        try{while(c.moveToNext()){n++;String date=c.getString(0);if(!date.equals(lastDate)){lastDate=date;TextView heading=text(prettyDate(date),13,getColorCompat(R.color.navy),true);heading.setPadding(dp(3),dp(8),0,dp(8));pageContent.addView(heading);}
            LinearLayout item=card();LinearLayout r=horizontal();r.addView(text(c.getString(3)+"  ·  "+c.getString(4),14,getColorCompat(R.color.text_primary),true),new LinearLayout.LayoutParams(0,-2,1));boolean p="PRESENT".equals(c.getString(2));r.addView(text(p?"PRESENT":"ABSENT",10,getColorCompat(p?R.color.green:R.color.red),true));item.addView(r);item.addView(text(c.getString(1),12,getColorCompat(R.color.text_secondary),false));LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,-2);ip.bottomMargin=dp(7);pageContent.addView(item,ip);
        }}finally{c.close();}
        if(n==0)showEmpty(pageContent,"No attendance history","Saved attendance records will appear here.");
    }

    private void showSettings() {
        currentScreen="settings";beginScreen("Settings",true);section(pageContent,"Data & exports","Your information stays on this device");
        LinearLayout export=card();export.addView(text("Export attendance",16,getColorCompat(R.color.text_primary),true));export.addView(text("Create a CSV spreadsheet that can be opened in Excel or shared with your faculty.",12,getColorCompat(R.color.text_secondary),false));addButton(export,"Save CSV to a location…",true,this::exportCsvWithPicker);addButton(export,"Share CSV report",false,this::shareCsv);pageContent.addView(export);gap(pageContent,14);
        LinearLayout info=card();info.addView(text("Application",16,getColorCompat(R.color.text_primary),true));info.addView(text("Smart Attendance Management System\nVersion 1.0\nOffline SQLite storage • No account required",12,getColorCompat(R.color.text_secondary),false));addButton(info,"About developer",false,this::showAbout);pageContent.addView(info);gap(pageContent,14);
        LinearLayout reset=card();reset.addView(text("Database reset",16,getColorCompat(R.color.red),true));reset.addView(text("Permanently delete all students, subjects and attendance records on this device.",12,getColorCompat(R.color.text_secondary),false));addButton(reset,"Reset all application data",false,this::confirmReset);pageContent.addView(reset);
    }

    private void showAbout() {
        currentScreen="about";beginScreen("About developer",true);
        LinearLayout hero=vertical();hero.setGravity(Gravity.CENTER);hero.setPadding(dp(20),dp(25),dp(20),dp(25));hero.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{getColorCompat(R.color.navy),getColorCompat(R.color.royal_blue)}));((GradientDrawable)hero.getBackground()).setCornerRadius(dp(22));
        TextView logo=text("✓",42,0xFFFFFFFF,true);logo.setGravity(Gravity.CENTER);GradientDrawable lbg=new GradientDrawable();lbg.setColor(0x33FFFFFF);lbg.setCornerRadius(dp(28));logo.setBackground(lbg);hero.addView(logo,new LinearLayout.LayoutParams(dp(82),dp(82)));
        TextView app=text("Smart Attendance",21,0xFFFFFFFF,true);app.setGravity(Gravity.CENTER);LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,-2);ap.topMargin=dp(15);hero.addView(app,ap);
        TextView sub=text("MANAGEMENT SYSTEM",11,0xFFDCE7FF,true);sub.setGravity(Gravity.CENTER);hero.addView(sub);pageContent.addView(hero);gap(pageContent,16);
        LinearLayout details=card();details.addView(text("DEVELOPER CREDITS",10,getColorCompat(R.color.text_secondary),true));gap(details,8);details.addView(text("Developed by",12,getColorCompat(R.color.text_secondary),false));details.addView(text("Deepanshu",20,getColorCompat(R.color.text_primary),true));gap(details,7);details.addView(text("Roll Number",12,getColorCompat(R.color.text_secondary),false));details.addView(text("22001017017",17,getColorCompat(R.color.navy),true));gap(details,14);details.addView(text("College Project",14,getColorCompat(R.color.royal_blue),true));details.addView(text("A fully offline attendance tracking application built with Java, XML layouts and SQLite.",12,getColorCompat(R.color.text_secondary),false));pageContent.addView(details);gap(pageContent,15);
        TextView footer=text("Made with care  •  Version 1.0",11,getColorCompat(R.color.text_secondary),false);footer.setGravity(Gravity.CENTER);pageContent.addView(footer);
    }

    private void confirmReset() {
        new AlertDialog.Builder(this).setTitle("Reset database?").setMessage("This will permanently remove every student, subject and attendance record. This action cannot be undone.").setNegativeButton("Cancel",null).setPositiveButton("Reset database",(d,w)->{try{database.resetAllData();selectedSubjectId=-1;attendanceStates.clear();toast("All local data has been reset.");showDashboard();}catch(Exception e){toast("Database reset failed.");}}).show();
    }

    private String buildCsv() {
        StringBuilder csv=new StringBuilder("Date,Student Name,Roll Number,Course,Semester,Subject,Status\r\n");Cursor c=database.getAllCsvRows();
        try{while(c.moveToNext()){for(int i=0;i<7;i++){if(i>0)csv.append(',');csv.append(csvCell(c.getString(i)));}csv.append("\r\n");}}finally{c.close();}
        return csv.toString();
    }
    private String csvCell(String value) { if(value==null)return "\"\"";return "\""+value.replace("\"","\"\"")+"\""; }
    private void exportCsvWithPicker() {
        pendingCsv=buildCsv();Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("text/csv");intent.putExtra(Intent.EXTRA_TITLE,"SmartAttendance_Report.csv");
        try{startActivityForResult(intent,REQUEST_CREATE_CSV);}catch(Exception e){toast("No file manager is available to save the report.");}
    }
    private void shareCsv() {
        try{File file=new File(getCacheDir(),"attendance.csv");try(FileOutputStream out=new FileOutputStream(file)){out.write(buildCsv().getBytes("UTF-8"));}
            Uri uri=Uri.parse("content://"+getPackageName()+".csvprovider/attendance.csv");Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/csv");send.putExtra(Intent.EXTRA_SUBJECT,"Smart Attendance Report");send.putExtra(Intent.EXTRA_TEXT,"Attendance report exported from Smart Attendance Management System.");send.putExtra(Intent.EXTRA_STREAM,uri);send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(send,"Share attendance report"));
        }catch(Exception e){toast("Could not prepare the CSV for sharing.");}
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);if(requestCode==REQUEST_CREATE_CSV&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){
            try(OutputStream out=getContentResolver().openOutputStream(data.getData())){if(out==null)throw new Exception("No output stream");out.write(pendingCsv.getBytes("UTF-8"));toast("CSV report saved successfully.");}
            catch(Exception e){toast("Could not save the CSV file.");}
        }
    }

    private void toast(String message) { Toast.makeText(this,message,Toast.LENGTH_SHORT).show(); }
    @Override public void onBackPressed() {
        if("dashboard".equals(currentScreen)){super.onBackPressed();return;}
        if("student_details".equals(currentScreen)||"history".equals(currentScreen)||"reports".equals(currentScreen)||"settings".equals(currentScreen)||"students".equals(currentScreen)||"attendance".equals(currentScreen)||"about".equals(currentScreen))showDashboard();else super.onBackPressed();
    }
    @Override protected void onDestroy() { if(database!=null)database.close();super.onDestroy(); }
}
