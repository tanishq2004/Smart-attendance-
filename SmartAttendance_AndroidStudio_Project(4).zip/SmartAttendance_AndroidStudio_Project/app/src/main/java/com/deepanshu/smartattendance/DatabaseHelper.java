package com.deepanshu.smartattendance;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Local SQLite storage for students, subjects and attendance. No network services are used. */
public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "smart_attendance.db";
    private static final int DB_VERSION = 1;

    public DatabaseHelper(Context context) { super(context, DB_NAME, null, DB_VERSION); }

    @Override public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE students (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT NOT NULL," +
                "roll_no TEXT NOT NULL COLLATE NOCASE UNIQUE," +
                "course TEXT NOT NULL," +
                "semester TEXT NOT NULL)");
        db.execSQL("CREATE TABLE subjects (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT NOT NULL COLLATE NOCASE UNIQUE)");
        db.execSQL("CREATE TABLE attendance (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "student_id INTEGER NOT NULL," +
                "subject_id INTEGER NOT NULL," +
                "attendance_date TEXT NOT NULL," +
                "status TEXT NOT NULL CHECK(status IN ('PRESENT','ABSENT'))," +
                "FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE," +
                "FOREIGN KEY(subject_id) REFERENCES subjects(id) ON DELETE CASCADE," +
                "UNIQUE(student_id, subject_id, attendance_date))");
        db.execSQL("CREATE INDEX idx_attendance_date ON attendance(attendance_date)");
        db.execSQL("CREATE INDEX idx_attendance_student ON attendance(student_id)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS attendance");
        db.execSQL("DROP TABLE IF EXISTS subjects");
        db.execSQL("DROP TABLE IF EXISTS students");
        onCreate(db);
    }

    public static class Student {
        public long id; public String name, roll, course, semester;
        Student(long id, String name, String roll, String course, String semester) {
            this.id=id; this.name=name; this.roll=roll; this.course=course; this.semester=semester;
        }
    }
    public static class Subject { public long id; public String name; Subject(long id, String name) { this.id=id; this.name=name; } }
    public static class Summary {
        public int classes, present, absent;
        public double percentage() { return classes == 0 ? 0 : (present * 100.0 / classes); }
    }
    public static class SubjectSummary extends Summary { public long subjectId; public String subjectName; public int conductedClasses; }

    public List<Student> getStudents(String filter) {
        List<Student> result = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String q = filter == null ? "" : filter.trim();
        Cursor c = db.query("students", new String[]{"id","name","roll_no","course","semester"},
                q.isEmpty() ? null : "name LIKE ? OR roll_no LIKE ?",
                q.isEmpty() ? null : new String[]{"%"+q+"%", "%"+q+"%"}, null, null, "name COLLATE NOCASE ASC");
        try { while (c.moveToNext()) result.add(new Student(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4))); }
        finally { c.close(); }
        return result;
    }

    public Student getStudent(long id) {
        Cursor c = getReadableDatabase().rawQuery("SELECT id,name,roll_no,course,semester FROM students WHERE id=?", new String[]{String.valueOf(id)});
        try { return c.moveToFirst() ? new Student(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4)) : null; }
        finally { c.close(); }
    }

    public boolean saveStudent(long id, String name, String roll, String course, String semester) {
        ContentValues v = new ContentValues(); v.put("name",name.trim()); v.put("roll_no",roll.trim()); v.put("course",course.trim()); v.put("semester",semester.trim());
        SQLiteDatabase db = getWritableDatabase();
        try {
            if (id == 0) return db.insertOrThrow("students", null, v) > 0;
            return db.update("students",v,"id=?",new String[]{String.valueOf(id)}) > 0;
        } catch (SQLiteConstraintException e) { return false; }
    }

    public boolean deleteStudent(long id) { return getWritableDatabase().delete("students","id=?",new String[]{String.valueOf(id)}) > 0; }

    public List<Subject> getSubjects() {
        List<Subject> result = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery("SELECT id,name FROM subjects ORDER BY name COLLATE NOCASE", null);
        try { while(c.moveToNext()) result.add(new Subject(c.getLong(0),c.getString(1))); }
        finally { c.close(); }
        return result;
    }

    public long addSubject(String name) {
        ContentValues v = new ContentValues(); v.put("name",name.trim());
        try { return getWritableDatabase().insertOrThrow("subjects",null,v); }
        catch (SQLiteConstraintException e) { return -1; }
    }

    public Map<Long, Boolean> getAttendanceForDate(long subjectId, String date) {
        Map<Long, Boolean> result = new LinkedHashMap<>();
        Cursor c = getReadableDatabase().rawQuery("SELECT student_id,status FROM attendance WHERE subject_id=? AND attendance_date=?",
                new String[]{String.valueOf(subjectId),date});
        try { while(c.moveToNext()) result.put(c.getLong(0), "PRESENT".equals(c.getString(1))); }
        finally { c.close(); }
        return result;
    }

    /** Replaces any existing record for the same student, subject and date. */
    public int saveAttendance(long subjectId, String date, Map<Long, Boolean> states) {
        SQLiteDatabase db = getWritableDatabase(); int count = 0;
        db.beginTransaction();
        try {
            for (Map.Entry<Long, Boolean> entry : states.entrySet()) {
                ContentValues v = new ContentValues();
                v.put("student_id",entry.getKey()); v.put("subject_id",subjectId); v.put("attendance_date",date);
                v.put("status",Boolean.TRUE.equals(entry.getValue()) ? "PRESENT" : "ABSENT");
                db.insertWithOnConflict("attendance",null,v,SQLiteDatabase.CONFLICT_REPLACE); count++;
            }
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
        return count;
    }

    public int[] getDashboardStats(String today) {
        SQLiteDatabase db = getReadableDatabase();
        int students = scalar(db,"SELECT COUNT(*) FROM students",null);
        int todayTotal = scalar(db,"SELECT COUNT(*) FROM attendance WHERE attendance_date=?",new String[]{today});
        int todayPresent = scalar(db,"SELECT COUNT(*) FROM attendance WHERE attendance_date=? AND status='PRESENT'",new String[]{today});
        int allTotal = scalar(db,"SELECT COUNT(*) FROM attendance",null);
        int allPresent = scalar(db,"SELECT COUNT(*) FROM attendance WHERE status='PRESENT'",null);
        return new int[]{students,todayTotal,todayPresent,todayTotal-todayPresent,allTotal == 0 ? 0 : Math.round(allPresent*100f/allTotal)};
    }

    private int scalar(SQLiteDatabase db, String sql, String[] args) {
        Cursor c = db.rawQuery(sql,args); try { return c.moveToFirst() ? c.getInt(0) : 0; } finally { c.close(); }
    }

    public Summary getStudentSummary(long studentId) {
        Summary s = new Summary();
        Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*),SUM(CASE WHEN status='PRESENT' THEN 1 ELSE 0 END) FROM attendance WHERE student_id=?",
                new String[]{String.valueOf(studentId)});
        try { if(c.moveToFirst()) { s.classes=c.getInt(0); s.present=c.getInt(1); s.absent=s.classes-s.present; } }
        finally { c.close(); }
        return s;
    }

    public List<SubjectSummary> getSubjectSummaries() {
        List<SubjectSummary> result = new ArrayList<>();
        String sql = "SELECT s.id,s.name,COUNT(a.id),SUM(CASE WHEN a.status='PRESENT' THEN 1 ELSE 0 END),COUNT(DISTINCT a.attendance_date) " +
                "FROM subjects s LEFT JOIN attendance a ON a.subject_id=s.id GROUP BY s.id,s.name ORDER BY s.name COLLATE NOCASE";
        Cursor c = getReadableDatabase().rawQuery(sql,null);
        try { while(c.moveToNext()) { SubjectSummary s=new SubjectSummary(); s.subjectId=c.getLong(0); s.subjectName=c.getString(1); s.classes=c.getInt(2); s.present=c.getInt(3); s.absent=s.classes-s.present; s.conductedClasses=c.getInt(4); result.add(s); } }
        finally { c.close(); }
        return result;
    }

    public Cursor getHistory(long studentId) {
        return getReadableDatabase().rawQuery("SELECT a.attendance_date,su.name,a.status,st.name,st.roll_no " +
                "FROM attendance a JOIN subjects su ON su.id=a.subject_id JOIN students st ON st.id=a.student_id " +
                (studentId > 0 ? "WHERE a.student_id=? " : "") + "ORDER BY a.attendance_date DESC,su.name COLLATE NOCASE",
                studentId > 0 ? new String[]{String.valueOf(studentId)} : null);
    }

    public void resetAllData() {
        SQLiteDatabase db = getWritableDatabase(); db.beginTransaction();
        try { db.delete("attendance",null,null); db.delete("students",null,null); db.delete("subjects",null,null); db.setTransactionSuccessful(); }
        finally { db.endTransaction(); }
    }

    public Cursor getAllCsvRows() {
        return getReadableDatabase().rawQuery("SELECT a.attendance_date,st.name,st.roll_no,st.course,st.semester,su.name,a.status " +
                "FROM attendance a JOIN students st ON st.id=a.student_id JOIN subjects su ON su.id=a.subject_id " +
                "ORDER BY a.attendance_date DESC,st.roll_no COLLATE NOCASE",null);
    }
}
