# Smart Attendance Management System

**Developer:** Deepanshu  
**Roll Number:** 22001017017  
**Project type:** College Project  
**Platform:** Android (Java + XML + SQLite), fully offline

## Features

- Dashboard with student totals, today's attendance counts and overall attendance percentage.
- Student add, edit, delete and search (name / roll number); duplicate roll numbers are rejected by SQLite.
- Subject creation and date-wise attendance marking, including Mark All Present.
- Attendance can be reopened and edited for the same student + subject + date. A database UNIQUE constraint prevents duplicate records.
- Subject-wise and individual reports, below-75% highlighting and date-wise attendance history.
- CSV export using Android's document picker and CSV sharing using an internal read-only content provider.
- About / developer credits and a confirmed local database reset.
- No Internet permission, Firebase, backend, API or third-party runtime dependency.

## Open and build in Android Studio

1. Install a recent Android Studio release with Android SDK Platform 35 and a compatible Android Build Tools package.
2. Extract `SmartAttendance_AndroidStudio_Project.zip`.
3. In Android Studio choose **Open**, then select the extracted `SmartAttendance_AndroidStudio_Project` folder.
4. Allow Android Studio to sync Gradle and install any requested SDK components.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. The debug APK is normally generated at `app/build/outputs/apk/debug/app-debug.apk`. Rename it to `SmartAttendance.apk` if desired.
7. To install on a connected device, enable USB debugging and use **Run** in Android Studio, or install the generated APK from the device.

## Build configuration

- Gradle distribution: 8.7 (the included lightweight bootstrap launcher downloads it on first build)
- Android Gradle Plugin: 8.6.1
- Compile SDK: 35
- Target SDK: 35
- Minimum SDK: 23 (Android 6.0)
- Java source / target compatibility: 17
- Application ID: `com.deepanshu.smartattendance`

This environment did not contain an Android SDK or a Gradle installation, and outbound network/DNS access was unavailable. The included Gradle bootstrap launcher attempted to download Gradle 8.7 but failed at DNS resolution before Gradle could start. Therefore an Android compilation or emulator/device test could not be performed here. The project files and build configuration are provided, but this archive does **not** claim to contain a compiled or tested APK. Android Studio will need to download the configured Gradle distribution, Android Gradle Plugin and Android SDK components on a machine with network access.

## Data model

- `students`: unique case-insensitive roll number, name, course and semester.
- `subjects`: unique case-insensitive subject name.
- `attendance`: foreign keys to student and subject, ISO date (`yyyy-MM-dd`), status (`PRESENT` / `ABSENT`), and unique `(student_id, subject_id, attendance_date)` key.

All application data is stored in the app's private SQLite database and remains on-device until deleted or the app is uninstalled / its data is cleared.
