@echo off
set APP_HOME=%~dp0
if defined JAVA_HOME (set JAVA_CMD=%JAVA_HOME%\bin\java.exe) else (set JAVA_CMD=java.exe)
"%JAVA_CMD%" %JAVA_OPTS% -classpath "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
exit /b %ERRORLEVEL%
